package Examen;
import java.util.Iterator;
import java.util.Scanner;
public class main3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sn= new Scanner(System.in);
		int A[]=null,B[]=null,C[]=null;
		String Si="Si";
		String name="MaryCecy", pasword="SISTEM2344";
		
		
		for (int i = 0; i < 3; i++) {
			System.out.println("Ingrese Usuario:");
			String name1=sn.nextLine();
			System.out.println("Ingrese Contraseña:");
			String pasword1=sn.nextLine();

			
			if (name1.equals(name) && pasword1.equals(pasword)) {
				System.out.println("Bienvenido");
		
			
				System.out.println("Escoja 1.Registrar - 2.Realizar Tramite - 3. Venta - 4. Salir");
				int op=sn.nextInt();
		
		
		
		switch (op) {
		case 1: {
			System.out.println("Cuantos productos desea llevar:");
			int cant=sn.nextInt();
			A=new int[cant];
			B=new int[cant];
			C=new int[cant];
			for (int j = 0; j < A.length; j++) {
				System.out.println("Cantidad del Producto "+(j+1)+":");
				int v=sn.nextInt();
				A[j]=v;
				
				System.out.println("Valor del Producto "+(j+1)+":");
				int v2=sn.nextInt();
				B[i]=v2;
				
				C[j]=A[j]*B[j];	
				
			}
			
		}
		
		case 2:{
			sn.nextLine();
			System.out.println("Desea proceder a realizar su compra:");
			String v=sn.nextLine();
			if(v.equals(Si)) {
				System.out.println("VENTA REALIZADA");
			}else {
				System.out.println("VENTA SUSPENDIDA");
			}
			
		}
		
		
		case 3:{
			System.out.printf("| %-12s | %-12s | %-12s | %-12s |\n", "Producto", "Cantidad", "Total a Pagar");
			for ( int j = 0; j <A.length; j++) {
				System.out.printf("| %-12s | %-12s | %-12s | %-12s |\n", j+1, A[j], B[j],C[j]);
			}
		}
			
		
		
		
		case 4:{
			System.out.println("Ha Salido del Sistema");
		}
		
			}
			
			
			
				}
		}
		
		
	}
}


		
		
			
		
		

	


