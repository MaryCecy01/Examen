package Examen;
import java.util.Scanner;
public class Examen {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sn= new Scanner(System.in);

	}

}
