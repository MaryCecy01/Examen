package ExamenI;

public class Ejercicio2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double []A=new double [7];
		A[0]=100;
		A[1]=-120;
		A[2]=300;
		A[3]=-0.4;
		A[4]=50;
		A[5]=170;
		A[6]=115;
		
	    for (int i = 1; i < 7; ++i) {
	        double aux = A[i];
	        int j = i - 1;

	        while (j >= 0 && A[j] > aux) {
	            A[j + 1] = A[j];
	            j = j - 1;
	        }
	        A[j + 1] = aux;}
	    
	    for (int i = 0; i < A.length; i++) {
			System.out.println("A["+i+"] = "+A[i]);
			
		}


	}

}
