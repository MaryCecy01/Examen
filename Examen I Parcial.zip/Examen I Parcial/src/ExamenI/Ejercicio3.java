package ExamenI;

import java.util.Scanner;

public class Ejercicio3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc= new Scanner(System.in);
		int []F=new int [6];
		F[0]=0;
		F[1]=1;
		for (int i = 2; i < F.length; i++) {
			F[i]=F[i-1]+F[i-2];
		}
		
		System.out.println("Los primeros 6 numeros de la serie Fibonacci son:");
		System.out.println(" ");
		for (int i = 0; i < F.length; i++) {
			System.out.println(F[i]);
		}


	}

}
