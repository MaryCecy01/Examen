package ExamenI;

import java.util.Locale;
import java.util.Scanner;

public class Ejercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sn= new Scanner(System.in);
		sn.useLocale(Locale.US);
		int A[]=null;
		int B[]=null,C[]=null;
		int cont=0,a = 0,cant=0;
		String Si="Si",Yes="Si",N[]=null;
		String us="MaryCecy", contra="SISTEM2344";
		
		
		do {
			System.out.println("Ingrese Nombre de Usuario");
			String intento1=sn.nextLine();
			System.out.println("Ingrese Contraseña");
			String intento=sn.nextLine();
			
			if((us.equals(intento1)) && (contra.equals(intento))) {
				System.out.println("Bienvenido");
				a=1;
				
				System.out.println("Escoja una opción: ");
				System.out.println("");
				System.out.println("a. Registrar");
				System.out.println("b. Realizar tramite");
				System.out.println("c. Imprimir Factura");
				System.out.println("d. Salir");
				System.out.println("");
				String op=sn.nextLine();
				op.equalsIgnoreCase("ABCD");
				
				
				switch (op) {
				case "a": {
					
					System.out.println("Cuantos productos desea llevar:");
					cant=sn.nextInt();
					A=new int[cant];
					B=new int[cant];
					C=new int[cant];
					N=new String [cant];
					
					for (int j = 0; j < A.length; j++) {
						sn.nextLine();
						System.out.println("Ingrese nombre del Producto");
						String n=sn.nextLine();
						N[j]=n;
						try {
						System.out.println("Cantidad del Producto "+(j+1)+":");
						int v=sn.nextInt();
						A[j]=v;
						
						System.out.println("Valor del Producto "+(j+1)+":");
						int v2=sn.nextInt();
						B[j]=v2;
						
						C[j]=A[j]*B[j];	
						
					
				} catch (java.util.InputMismatchException m){
					System.out.println("Error el dato debe ser numerico");
				}
				}
				}
				case "b":{
					sn.nextLine();
					System.out.println("Desea proceder a realizar su compra:");
					String v=sn.nextLine();
					if(v.equals(Si)) {
						System.out.println("VENTA REALIZADA");
					}else {
						System.out.println("VENTA SUSPENDIDA");
					}
					
				}
				case "c":{
					System.out.println(" ");
					System.out.printf("%-15s|%-15s|%-15s|%-15s|%n","Producto","Cantidad","Precio","Total ");
					for (int j=0;j<cant;j++) { 
				         System.out.println("---------------------------------------------------------------");
						 System.out.printf("%-15s|%-15d|%-15d|%-15d|%n",N[j],A[j],B[j],C[j]); 
						}
					
				}
				case "d":{
					System.out.println("");
					System.out.println("Desea Salir de su Cuenta? (Si)(No):");
					String yes1=sn.nextLine();
					if(yes1.equals(Yes)) {
						System.out.println("....Ha salido del Programa...");
						break;
					}else {
						System.out.println("Continua dentro ;)");
					}
				}
					}
				
			}else {
				System.out.println("Nombre de Usuario o Contraseña Incorrecto");
				cont++;
				if(cont==3) {
					System.out.println("Ha exedido  el numero de intentos...¡Acceso Restringido!");
					
				}
			}
		}while((cont!=3)&& a==0);
		

	}

}
